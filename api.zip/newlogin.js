
const loginForm = document.getElementById('login--form');
const signupForm = document.getElementById('signup-form');


if (loginForm) {
  loginForm.addEventListener('submit', (event) => {
    // Your login form submission logic goes here
  });
} else {
  console.error("Login form element not found.");
}


loginForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const username = event.target.username.value;
  const password = event.target.password.value;

  // Use Firebase Authentication API to sign in with email and password
  firebase.auth().signInWithEmailAndPassword(username, password)
    .then((userCredential) => {
      // Login successful, do something (e.g., redirect to a dashboard)
      const user = userCredential.user
      console.log('Login successful');
      console.log("welcome ", user.email);
    })
    .catch((error) => {
      // Handle login errors (e.g., incorrect credentials)
      console.error('Login error:', error.message);
    });
});

// Add event listener for signup form submit
signupForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const newUsername = event.target['new-username'].value;
  const newPassword = event.target['new-password'].value;

  // Use Firebase Authentication API to create a new user with email and password
  firebase.auth().createUserWithEmailAndPassword(newUsername, newPassword)
    .then((userCredential) => {
      // Signup successful, do something (e.g., redirect to a profile page)
      console.log('Signup successful');
    })
    .catch((error) => {
      // Handle signup errors (e.g., weak password, email already in use)
      console.error('Signup error:', error.message);
    });
});
