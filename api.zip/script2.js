const loginIcon = document.getElementById('login-btn');

loginIcon.addEventListener('click', () => {
  window.location.href = 'newlogin.html';
});
